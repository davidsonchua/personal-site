#!/usr/bin/env python3
"""Page content for davidsonchua.cc — run via build.py"""
import os, shutil, json, html
from build import (BASE, OUT, PERSON_ID, SITE_ID, INFLUENCEES_ID, AUTOSAVE_ID,
                   PERSON, CORE_GRAPH, page, write, breadcrumb, TODAY, head)

# ===========================================================================
# HOME
# ===========================================================================

HOME_BODY = """
    <section class="hero">
      <div class="shell">
        <div class="portrait">
          <img src="/assets/profile-400.webp" width="132" height="132" fetchpriority="high"
               alt="Portrait of Davidson Chua, Singapore-based founder of Influencees and Autosave">
        </div>

        <h1>Davidson Chua</h1>
        <p class="lead">
          I'm a Singapore-based founder and community builder. I'm the co-founder and CEO of
          <a href="https://www.influencees.com" rel="noopener">Influencees</a>, the creator
          credibility and discovery platform for Southeast Asia, and the founder of
          <a href="https://www.autosave.club" rel="noopener">Autosave</a>, Singapore's most
          active automotive community.
        </p>

        <ul class="heroFacts">
          <li>Co-founder &amp; CEO, Influencees</li>
          <li>Founder, Autosave</li>
          <li>NUS Business Analytics</li>
          <li>Singapore</li>
        </ul>

        <div class="ctaRow">
          <a class="btn" href="/about">Read my full story</a>
          <a class="btn ghost" href="https://www.linkedin.com/in/davidsonchua/" rel="me noopener">Connect on LinkedIn</a>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <p class="eyebrow">By the numbers</p>
        <h2>What I've built</h2>
        <ul class="stats">
          <li><span class="statNum">18,000+</span><span class="statLabel">Autosave community members</span></li>
          <li><span class="statNum">1,200+</span><span class="statLabel">Creators indexed on Influencees</span></li>
          <li><span class="statNum">20M+</span><span class="statLabel">Monthly road-safety impressions via ROADS.sg</span></li>
          <li><span class="statNum">1,000+</span><span class="statLabel">Attendees at Autosave events</span></li>
        </ul>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <p class="eyebrow">Ventures</p>
        <h2>What I'm working on</h2>
        <div class="cards">

          <a class="card" href="https://www.influencees.com" rel="noopener">
            <div class="cardTop">
              <span class="cardName">Influencees</span>
              <span class="tag">Co-founder &amp; CEO · 2026</span>
            </div>
            <p>An AI-powered creator credibility and discovery platform for Southeast Asia.
              Influencees syncs data directly from Instagram and TikTok so brands can judge
              creators on verified engagement instead of self-reported follower counts.</p>
            <span class="cardLink">www.influencees.com</span>
          </a>

          <a class="card" href="https://www.autosave.club" rel="noopener">
            <div class="cardTop">
              <span class="cardName">Autosave</span>
              <span class="tag">Founder · 2022</span>
            </div>
            <p>Singapore's most active automotive community — 18,000+ members, owner meets,
              and motoring media. Brand campaigns with Mercedes-Benz, Shell, Porsche and
              Volkswagen Group. Named Best Automotive Community &amp; Media Platform 2025 &mdash; Singapore.</p>
            <span class="cardLink">www.autosave.club</span>
          </a>

        </div>
        <p class="small muted" style="margin-top:16px">
          <a href="/ventures">More on both ventures →</a>
        </p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <p class="eyebrow">Background</p>
        <h2>How I got here</h2>
        <ul class="tl">
          <li>
            <span class="tlWhen">2026 —</span>
            <div class="tlWhat"><strong>Co-founder &amp; CEO, Influencees</strong>
              <p>Co-founded with Edwin Koh out of the NUS Venture Initiation Programme. Raised a
                six-figure round to build the trust layer for the creator economy.</p></div>
          </li>
          <li>
            <span class="tlWhen">2022 —</span>
            <div class="tlWhat"><strong>Founder, Autosave</strong>
              <p>Grew a Telegram group into Singapore's most active automotive community and
                incorporated it as Autosave Pte. Ltd.</p></div>
          </li>
          <li>
            <span class="tlWhen">2022–2026</span>
            <div class="tlWhat"><strong>BSc (Hons) Business Analytics, National University of Singapore</strong>
              <p>Where the analytics habit that underpins Influencees came from.</p></div>
          </li>
          <li>
            <span class="tlWhen">Earlier</span>
            <div class="tlWhat"><strong>Marine engineering — BP, and Singapore Polytechnic</strong>
              <p>Diploma with Merit in Marine Engineering, then engineering work at BP before
                moving into media and community building.</p></div>
          </li>
        </ul>
        <p class="small muted" style="margin-top:20px">
          <a href="/about">Read the longer version →</a>
        </p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <p class="eyebrow">In the press</p>
        <h2>Selected media</h2>
        <p class="muted">Profiled by <a href="https://www.techinasia.com/meet-ai-platform-helps-brands-evaluate-content-creators" rel="noopener">Tech in Asia</a> in its Startup
          Spotlight series, interviewed by <a href="https://technode.global/2026/08/24/influencees-davidson-chua-on-measuring-creator-influence-beyond-follower-count-qa/" rel="noopener">TNGlobal</a> on measuring
          creator influence beyond follower count, profiled by NUS Computing, featured in
          The Straits Times on Singapore's tech ambitions, and a guest on three episodes of the ST
          <em>Work Talk</em> podcast. Panellist at ChargedUp 2026, Singapore's largest EV conference, and at Sgcarmart's Beyond Motion 2026.</p>
        <p class="small"><a href="/media">See all media features →</a></p>
      </div>
    </section>
"""

# ===========================================================================
# ABOUT  — the Entity Home. This is the page Google reads to resolve "who".
# ===========================================================================

ABOUT_BODY = """
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">About</p>
        <h1>About Davidson Chua</h1>
        <p class="lead">
          Davidson Chua is a Singapore-based founder and community builder. He is the co-founder
          and CEO of Influencees, an AI-powered creator credibility and discovery platform for
          Southeast Asia, and the founder of Autosave, Singapore's most active automotive
          community with more than 18,000 members.
        </p>

        <div class="portrait" style="margin:26px 0">
          <img src="/assets/profile-400.webp" width="132" height="132"
               alt="Davidson Chua, co-founder and CEO of Influencees">
        </div>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>The short version</h2>
        <p>I started out as a marine engineer. I took a Diploma with Merit in Marine
          Engineering at Singapore Polytechnic and went on to work at <strong>BP</strong>, which is
          about as far from the creator economy as a career can start. What I took from it was a
          bias towards things that actually work under load — systems, not slogans.</p>

        <p>I then read Business Analytics at the <strong>National University of Singapore</strong>,
          graduating with a BSc (Honours). Somewhere in the middle of that I started a Telegram
          group for people who liked cars. That group became
          <a href="https://www.autosave.club" rel="noopener">Autosave</a>.</p>

        <h2>Autosave</h2>
        <p>Autosave grew from a chat group into Singapore's most active automotive community:
          <strong>18,000+ members</strong>, regular owner meets drawing over a thousand attendees,
          and a motoring media arm. Along the way we ran brand campaigns with
          <strong>Mercedes-Benz</strong>, <strong>Shell</strong>, <strong>Porsche</strong>,
          <strong>Volkswagen Group</strong>, Cycle &amp; Carriage, SGCarMart, Carousell Autos,
          Motorist and GetGo.</p>

        <p>The business was incorporated as <strong>Autosave Pte. Ltd.</strong> (UEN 202431449C)
          and incubated at <strong>NUS Enterprise</strong> and <strong>BLOCK71</strong>. In 2025 it was
          named <strong><a href="https://www.corporatevision-news.com/winners/sg-cars/" rel="noopener">Best
          Automotive Community &amp; Media Platform 2025 &mdash; Singapore</a></strong> in Corporate
          Vision's Automotive Awards.</p>

        <h2>Influencees</h2>
        <p>Running Autosave meant sitting on both sides of a lot of brand deals, and the same
          problem kept surfacing: brands could not tell which creators were actually trusted by
          their audience. Follower count was the only number anyone had, and it is a bad number.
          Some of the most valuable creators I worked with did not have the largest followings.</p>

        <p>That became <a href="https://www.influencees.com" rel="noopener">Influencees</a>, which I
          co-founded with <strong>Edwin Koh</strong> — a relationship that started as a mentorship
          through the NUS Venture Initiation Programme (VIP@SoC). Influencees syncs performance data
          directly from Instagram and TikTok rather than relying on what creators report about
          themselves, and layers credibility signals on top: a verified creator index of
          <strong>1,200+ creators</strong>, a Trust Check, and an AI assistant for campaign work.</p>

        <p>We launched in June 2026, raised a six-figure round from a corporate venture investor, and
          were profiled by <a href="https://www.techinasia.com/meet-ai-platform-helps-brands-evaluate-content-creators" rel="noopener">Tech in Asia</a> in its Startup Spotlight
          series. The longer-term goal is an
          intelligence layer for the creator economy — the place brands go to find, evaluate and
          work with creators, and the place creators go to be found on more than a vanity metric.</p>

        <blockquote>Influencees is about giving brands a better way to discover creators, while
          giving creators more opportunities to be seen.</blockquote>

        <p>I went into this in more depth in a
          <a href="https://technode.global/2026/08/24/influencees-davidson-chua-on-measuring-creator-influence-beyond-follower-count-qa/" rel="noopener">Q&amp;A with TNGlobal</a>: follower count is useful as a rough
          indicator of reach, but it should rarely be the first or only signal anyone decides on.
          A high engagement rate alone doesn't fix it either — on a small audience base, a few dozen
          interactions produce a flattering percentage that means very little.</p>

        <h2>What I care about</h2>
        <p>Communities, and the infrastructure that makes them trustworthy. Almost everything I've
          built comes back to the same question: how do you know who to believe? In a car community
          that means honest reviews and real owner experience. In the creator economy it means
          verifiable data instead of screenshots. I care about building things that are useful,
          honest, and grounded in something I've actually done.</p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Quick facts</h2>
        <dl class="qa">
          <dt>Who is Davidson Chua?</dt>
          <dd>Davidson Chua is a Singapore-based entrepreneur and community builder, co-founder and
            CEO of Influencees and founder of Autosave.</dd>

          <dt>What does Davidson Chua do?</dt>
          <dd>He builds credibility and discovery infrastructure for the creator economy at
            Influencees, and runs Autosave, a Singapore automotive community and media business.</dd>

          <dt>Where is Davidson Chua based?</dt>
          <dd>Singapore.</dd>

          <dt>Where did Davidson Chua study?</dt>
          <dd>He holds a BSc (Honours) in Business Analytics from the National University of
            Singapore, and a Diploma with Merit in Marine Engineering from Singapore Polytechnic.</dd>

          <dt>What is Influencees?</dt>
          <dd>Influencees is an AI-powered creator credibility and discovery platform for Southeast
            Asia, co-founded by Davidson Chua and Edwin Koh in 2026. It syncs data directly from
            Instagram and TikTok so brands can evaluate creators on verified engagement.</dd>

          <dt>What is Autosave?</dt>
          <dd>Autosave (Autosave Pte. Ltd., UEN 202431449C) is Singapore's most active automotive
            community, founded by Davidson Chua in 2022, with more than 18,000 members.</dd>

          <dt>What awards has Davidson Chua's work won?</dt>
          <dd>Autosave was named
            <a href="https://www.corporatevision-news.com/winners/sg-cars/" rel="noopener">Best Automotive
            Community &amp; Media Platform 2025 &mdash; Singapore</a> in Corporate Vision's Automotive
            Awards.</dd>

          <dt>Where has Davidson Chua been interviewed?</dt>
          <dd>Most recently profiled by <a href="https://www.techinasia.com/meet-ai-platform-helps-brands-evaluate-content-creators" rel="noopener">Tech in Asia</a> (Startup
            Spotlight, August 2026) and interviewed in a <a href="https://technode.global/2026/08/24/influencees-davidson-chua-on-measuring-creator-influence-beyond-follower-count-qa/" rel="noopener">TNGlobal Q&amp;A</a> on measuring creator
            influence beyond follower count (August 2026). He has also been profiled by
            <a href="https://www.comp.nus.edu.sg/news/how-influencees-is-building-the-ai-layer-for-the-creator-economy/" rel="noopener">NUS
            Computing</a> and featured in The Straits Times. See the <a href="/media">media page</a>.</dd>

          <dt>How can I contact Davidson Chua?</dt>
          <dd>By <a href="mailto:davidsonchua@outlook.com">email</a>,
            <a href="https://www.linkedin.com/in/davidsonchua/" rel="me noopener">LinkedIn</a> or
            <a href="https://t.me/davidsonchua" rel="me noopener">Telegram</a>. See the
            <a href="/contact">contact page</a>.</dd>
        </dl>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Elsewhere on the web</h2>
        <p class="muted">These are the profiles I actually maintain. If you find a "Davidson Chua"
          somewhere that isn't listed here, it probably isn't me.</p>
        <ul class="contactList">
          <li><span class="k">LinkedIn</span><a href="https://www.linkedin.com/in/davidsonchua/" rel="me noopener">linkedin.com/in/davidsonchua</a></li>
          <li><span class="k">Crunchbase</span><a href="https://www.crunchbase.com/person/davidson-chua-cc" rel="me noopener">crunchbase.com/person/davidson-chua-cc</a></li>
          <li><span class="k">Medium</span><a href="https://davidsonchua.medium.com/" rel="me noopener">davidsonchua.medium.com</a></li>
          <li><span class="k">X</span><a href="https://x.com/davidsonchua" rel="me noopener">x.com/davidsonchua</a></li>
          <li><span class="k">Telegram</span><a href="https://t.me/davidsonchua" rel="me noopener">t.me/davidsonchua</a></li>
          <li><span class="k">Press enquiries</span><a href="https://www.helpareporter.com/journalist/davidsonchua" rel="me noopener">Connectively / HARO</a></li>
        </ul>
      </div>
    </section>
"""

# ===========================================================================
# VENTURES
# ===========================================================================

VENTURES_BODY = """
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">Ventures</p>
        <h1>Companies founded by Davidson Chua</h1>
        <p class="lead">Two businesses, both built around the same idea: markets work better when
          people can tell who — and what — to trust.</p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Influencees</h2>
        <p class="muted small">Co-founder &amp; CEO · Launched June 2026 · Singapore ·
          <a href="https://www.influencees.com" rel="noopener">influencees.com</a></p>

        <p>Influencees is an AI-powered creator credibility and discovery platform for Southeast
          Asia. Rather than trusting the numbers creators report about themselves, Influencees syncs
          performance data directly from <strong>Instagram and TikTok</strong>, then layers
          credibility signals on top so brands can evaluate who is genuinely trusted by an audience.</p>

        <h3>What's in it</h3>
        <ul>
          <li><strong>Verified creator index</strong> — 1,200+ creators with engagement figures pulled from source, not screenshots.</li>
          <li><strong>Trust Check</strong> — credibility checks on creators, including detection of AI-generated video.</li>
          <li><strong>Ai-kyo</strong> — an AI assistant for campaign insight and content ideation.</li>
          <li><strong>Campaign workspace</strong> — brief, shortlist, brief and track collaborations in one place.</li>
          <li><strong>Creator Pro</strong> — a dashboard letting creators surface their real performance to brands.</li>
        </ul>

        <h3>Story</h3>
        <p>Co-founded with <strong>Edwin Koh</strong>, whom I first met through the NUS Venture
          Initiation Programme (VIP@SoC) as a mentor. We raised a six-figure round from a corporate
          venture investor in April 2026 and launched in June 2026. Influencees
          also runs the <strong>Creator Creates Series</strong>, a creator hackathon — the 2026
          edition ran 19 creators, drew 1,700+ community votes and tracked 2,300+ link clicks.</p>

        <p><a class="btn ghost" href="https://www.influencees.com" rel="noopener">Visit Influencees</a></p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Autosave</h2>
        <p class="muted small">Founder · Founded 2022 · Autosave Pte. Ltd. (UEN 202431449C) ·
          <a href="https://www.autosave.club" rel="noopener">autosave.club</a></p>

        <p>Autosave is Singapore's most active automotive community — cars, media and meets. It
          started as a Telegram group and grew into a network of <strong>18,000+ members</strong>
          across Telegram and social channels, with owner meets that have drawn over a thousand
          attendees.</p>

        <h3>Brand campaigns</h3>
        <p class="muted">Mercedes-Benz · Shell · Porsche · Volkswagen Group · Cycle &amp; Carriage ·
          SGCarMart · Carousell Autos · Motorist · GetGo · SingSaver · MoneySmart</p>

        <h3>Recognition</h3>
        <ul>
          <li><a href="https://www.corporatevision-news.com/winners/sg-cars/" rel="noopener">Best Automotive
            Community &amp; Media Platform 2025 — Singapore</a>, Corporate Vision Automotive Awards</li>
          <li>Incubated at NUS Enterprise and BLOCK71</li>
        </ul>

        <h3>Channels</h3>
        <ul>
          <li><a href="https://baycityculture.com/" rel="noopener">Bay City Culture</a> — the motoring publication</li>
          <li>Telegram: @AutoSaveClub, @sgcarnews, @sgcarmeets</li>
        </ul>

        <p><a class="btn ghost" href="https://www.autosave.club" rel="noopener">Visit Autosave</a></p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Also involved in</h2>
        <div class="cards">
          <a class="card" href="https://roads.sg" rel="noopener">
            <div class="cardTop"><span class="cardName">ROADS.sg</span><span class="tag">Contributor</span></div>
            <p>Road safety media generating 20M+ monthly impressions across Singapore, working
              directly with the Traffic Police and the Land Transport Authority.</p>
            <span class="cardLink">roads.sg</span>
          </a>
          <a class="card" href="https://baycityculture.com/" rel="noopener">
            <div class="cardTop"><span class="cardName">Bay City Culture</span><span class="tag">Co-founder &amp; editor</span></div>
            <p>A Singapore motoring publication covering EVs, COE, ERP, charging infrastructure
              and the cost of car ownership.</p>
            <span class="cardLink">baycityculture.com</span>
          </a>
        </div>
      </div>
    </section>
"""

# ===========================================================================
# MEDIA
# ===========================================================================

MEDIA_BODY = """
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">Media</p>
        <h1>Davidson Chua in the press</h1>
        <p class="lead">Interviews, features, podcast appearances and speaking engagements. If
          you're a journalist looking for comment on the creator economy, community building or
          Singapore's automotive market, <a href="/contact">get in touch</a>.</p>
      </div>
    </section>

    <section class="section">
      <div class="shell">

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">Tech in Asia</span><span class="tag">Startup Spotlight</span></div>
          <h3>Meet the AI platform that helps brands evaluate content creators</h3>
          <p class="muted">Tech in Asia profiles Influencees in its Startup Spotlight series: how running
            Autosave exposed the gap in how brands price creator campaigns, the platform's verified
            network of 1,200+ Singapore creators since its June 2026 launch, and funding from a
            corporate venture investor. By Peter Cowan, 31&nbsp;August&nbsp;2026.</p>
          <p class="small"><a href="https://www.techinasia.com/meet-ai-platform-helps-brands-evaluate-content-creators" rel="noopener">Read the feature</a> ·
            shared by Tech in Asia on
            <a href="https://www.linkedin.com/posts/tech-in-asia_what-problem-does-it-solve-marketing-activity-7500417290429988864-zdTy" rel="noopener">LinkedIn</a>,
            <a href="https://www.facebook.com/techinasia/posts/1488592489970419" rel="noopener">Facebook</a> and
            <a href="https://www.instagram.com/p/Dcu3Idqljv-/" rel="noopener">Instagram</a></p>
          <figure>
            <img src="/assets/media/techinasia-spotlight.webp" width="1000" height="1249" loading="lazy" decoding="async"
                 alt="Tech in Asia Startup Spotlight graphic: This startup helps brands evaluate content creators — Singapore-based Influencees, with co-founders Davidson Chua and Edwin Koh">
          </figure>
          <p class="credit">Image credit: Tech in Asia</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">TNGlobal</span><span class="tag">Q&amp;A interview</span></div>
          <h3>Influencees' Davidson Chua on measuring creator influence beyond follower count</h3>
          <p class="muted">A long-form Q&amp;A with TNGlobal on why follower count is a weak decision
            signal, how attribution breaks down between consideration and conversion, and what
            creator verification should actually check. Interview by J. Angelo Racoma,
            24&nbsp;August&nbsp;2026.</p>
          <blockquote style="margin:14px 0;padding-left:18px;border-left:2px solid var(--hair2);color:var(--muted);font-style:italic">
            "Follower count is useful as a rough indicator of potential reach, but it should rarely
            be the first or only decision-making signal."
          </blockquote>
          <p class="small"><a href="https://technode.global/2026/08/24/influencees-davidson-chua-on-measuring-creator-influence-beyond-follower-count-qa/" rel="noopener">Read the full Q&amp;A</a></p>
          <figure>
            <img src="/assets/media/tnglobal-qa.webp" width="1000" height="1051" loading="lazy" decoding="async"
                 alt="TNGlobal Q&amp;A with Davidson Chua of Influencees on measuring creator influence beyond follower count">
          </figure>
          <p class="credit">Image credit: TNGlobal</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">BLOCK71 · NUS Enterprise</span><span class="tag">Feature</span></div>
          <h3>Here's what founders are talking about on social this month</h3>
          <p class="muted">BLOCK71 Global features Autosave as a case study on building inside chat
            apps and applying AI to real bottlenecks rather than flashy features, quoting Davidson
            Chua: "Don't automate for the sake of tech. Start with your biggest bottleneck, not the
            thing with the most wow factor." June 2026.</p>
          <p class="small"><a href="https://block71.co/heres-what-founders-are-talking-about-on-social-this-month/" rel="noopener">Read the article</a></p>
          <figure>
            <img src="/assets/media/block71-feature.webp" width="1000" height="818" loading="lazy" decoding="async"
                 alt="BLOCK71 Global feature 'The Reality Check' quoting Davidson Chua, Founder of Autosave, on building on Telegram and using AI for operations">
          </figure>
          <p class="credit">Image credit: BLOCK71 Global</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">The Straits Times</span><span class="tag">Feature</span></div>
          <h3>Singapore ranks as world's 12th tech city, with room to grow</h3>
          <p class="muted">Featured in an SPH Media / Straits Times report on Singapore's rise as a
            technology hub and the generation entering its tech workforce (October 2022). The
            article is republished by the Singapore Economic Development Board.</p>
          <p class="small"><a href="https://www.edb.gov.sg/en/business-insights/insights/singapore-ranks-as-world-s-12th-tech-city-with-room-to-grow-as-tech-savvy-generation-enter-job-market.html" rel="noopener">Read via Singapore EDB</a> ·
            <a href="https://www.ntu.edu.sg/business/news-events/news/story-detail/singapore-ranks-as-world-s-12th-tech-city-with-room-to-grow-as-tech-savvy-generation-enter-job-market" rel="noopener">via NTU Nanyang Business School</a></p>
          <figure>
            <img src="/assets/media/straits-times-feature.webp" width="1000" height="1164" loading="lazy" decoding="async"
                 alt="The Straits Times feature quoting Davidson Chua on Singapore's tech ambitions">
          </figure>
          <p class="credit">Photo credit: The Straits Times</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">ST Work Talk podcast</span><span class="tag">Guest</span></div>
          <h3>Singapore's rise as a tech city — and what it means for Singaporeans</h3>
          <p class="muted">On what the country's technology growth actually means for people
            entering the workforce. December 2022.</p>
          <p class="small"><a href="https://www.straitstimes.com/business/work-talk-podcast-singapore-s-rise-as-a-tech-city-and-what-it-means-for-singaporeans" rel="noopener">Listen to the episode</a></p>
          <figure>
            <img src="/assets/media/podcast-tech-city.webp" width="860" height="573" loading="lazy" decoding="async"
                 alt="Straits Times Work Talk podcast episode on Singapore as a tech city, featuring Davidson Chua">
          </figure>
          <p class="credit">Photo credit: The Straits Times</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">ST Work Talk podcast</span><span class="tag">Guest</span></div>
          <h3>Understanding tech culture at Salesforce and Cisco</h3>
          <p class="muted">In conversation with Salesforce's regional CTO for solutions and Cisco's
            regional cybersecurity leader on tech culture and where the jobs are.</p>
          <p class="small"><a href="https://www.straitstimes.com/business/work-talk-podcast-where-the-tech-jobs-are" rel="noopener">Listen to the episode</a></p>
          <figure>
            <img src="/assets/media/podcast-tech-jobs.webp" width="860" height="573" loading="lazy" decoding="async"
                 alt="Straits Times Work Talk podcast episode on tech jobs, featuring Davidson Chua">
          </figure>
          <p class="credit">Photo credit: The Straits Times</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">The Straits Times</span><span class="tag">Guest</span></div>
          <h3>Gen AI, you started work yet?</h3>
          <p class="muted">On beginning a career in a world shaped by tools like ChatGPT, and how
            expectations are shifting for young professionals. May 2024.</p>
          <p class="small"><a href="https://www.straitstimes.com/business/gen-ai-you-started-work-yet" rel="noopener">Listen to the episode</a></p>
          <figure>
            <img src="/assets/media/podcast-gen-ai.webp" width="860" height="573" loading="lazy" decoding="async"
                 alt="Straits Times podcast on generative AI, featuring Davidson Chua">
          </figure>
          <p class="credit">Photo credit: The Straits Times</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">NUS Computing</span><span class="tag">Profile</span></div>
          <h3>How Influencees is building the AI layer for the creator economy</h3>
          <p class="muted">NUS School of Computing on the founding of Influencees, the NUS Venture
            Initiation Programme, and the thesis behind the platform.</p>
          <p class="small"><a href="https://www.comp.nus.edu.sg/news/how-influencees-is-building-the-ai-layer-for-the-creator-economy/" rel="noopener">Read the article</a></p>
          <figure>
            <img src="/assets/media/nus-computing-influencees.webp" width="1000" height="698" loading="lazy" decoding="async"
                 alt="NUS Computing feature: An NUS Computing Alumnus Developing an AI Tool That's Rethinking How Brands Find Creators, on Davidson Chua and Influencees">
          </figure>
          <p class="credit">Image credit: NUS School of Computing</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">Corporate Vision</span><span class="tag">Award</span></div>
          <h3>Best Automotive Community &amp; Media Platform 2025 — Singapore</h3>
          <p class="muted">Autosave recognised in Corporate Vision's Automotive Awards for
            "strong grassroots engagement and relevant, community-driven content."</p>
          <p class="small"><a href="https://www.corporatevision-news.com/winners/sg-cars/" rel="noopener">See the winners page</a></p>
          <figure>
            <img src="/assets/media/corporate-vision-award.webp" width="1000" height="470" loading="lazy" decoding="async"
                 alt="Corporate Vision Automotive Awards 2025 winners page for SG Cars, Best Automotive Community and Media Platform 2025 Singapore">
          </figure>
          <p class="credit">Image credit: Corporate Vision</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">Sgcarmart Beyond Motion 2026</span><span class="tag">Speaker</span></div>
          <h3>Panellist — the future of mobility in Singapore</h3>
          <p class="muted">Panellist (Founder, Autosave) at Sgcarmart's Beyond Motion conference on
            mobility, electrification and ownership, alongside speakers from Allianz, NUS, Durapower,
            Voltality and VINCAR Group. 22 March 2026.</p>
          <p class="small"><a href="https://www.sgcarmart.com/campaign/beyond-motion" rel="noopener">See the speaker line-up</a></p>
          <figure>
            <img src="/assets/media/sgcarmart-beyond-motion.webp" width="1000" height="577" loading="lazy" decoding="async"
                 alt="Sgcarmart Beyond Motion 2026 speaker profile for Davidson Chua, Founder, Autosave">
          </figure>
          <p class="credit">Image credit: Sgcarmart</p>
        </article>

        <article class="mediaItem">
          <div class="mediaMeta"><span class="outlet">ChargedUp 2026</span><span class="tag">Speaker</span></div>
          <h3>Panel: Standards, Experience &amp; Adoption — Building an Interoperable EV Journey Across Southeast Asia</h3>
          <p class="muted">Panellist at ChargedUp 2026, Singapore's largest EV conference.
            Day 1, 23 July 2026, 14:20, Perennial Business City, Singapore.</p>
          <p class="small"><a href="https://www.chargedup.asia/" rel="noopener">chargedup.asia</a></p>
          <figure>
            <img src="/assets/media/chargedup-speaker.webp" width="1000" height="795" loading="lazy" decoding="async"
                 alt="ChargedUp 2026 speaker profile for Davidson Chua, Founder and Advisor, Autosave Pte. Ltd.">
          </figure>
          <p class="credit">Image credit: ChargedUp Asia</p>
        </article>

      </div>
    </section>
"""

# ===========================================================================
# CONTACT
# ===========================================================================

CONTACT_BODY = """
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">Contact</p>
        <h1>Contact Davidson Chua</h1>
        <p class="lead">Open to conversations about the creator economy, community building,
          brand partnerships, press comment and speaking.</p>

        <ul class="contactList">
          <li><span class="k">Email</span><a href="mailto:davidsonchua@outlook.com">davidsonchua@outlook.com</a></li>
          <li><span class="k">Contact card</span><a href="/davidson-chua.vcf" download="Davidson Chua.vcf">Save my contact (.vcf)</a> &middot; <a href="/card">view card</a></li>
          <li><span class="k">LinkedIn</span><a href="https://www.linkedin.com/in/davidsonchua/" rel="me noopener">linkedin.com/in/davidsonchua</a></li>
          <li><span class="k">Telegram</span><a href="https://t.me/davidsonchua" rel="me noopener">t.me/davidsonchua</a></li>
          <li><span class="k">X</span><a href="https://x.com/davidsonchua" rel="me noopener">@davidsonchua</a></li>
        </ul>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>For journalists</h2>
        <p>I'm available for comment on the creator economy and influencer marketing in Southeast
          Asia, community building, and Singapore's automotive and EV market. I'm listed on
          <a href="https://www.helpareporter.com/journalist/davidsonchua" rel="noopener">Connectively (formerly HARO)</a>.</p>

        <h3>Short bio (for use in articles)</h3>
        <p class="muted">Davidson Chua is the co-founder and CEO of Influencees, an AI-powered creator
          credibility and discovery platform for Southeast Asia, and the founder of Autosave,
          Singapore's most active automotive community with over 18,000 members. He holds a BSc
          (Honours) in Business Analytics from the National University of Singapore.</p>

        <h3>Headshot</h3>
        <p class="small"><a href="/assets/profile-800.webp" download>Download high-resolution photo (800×800)</a></p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Business details</h2>
        <ul class="contactList">
          <li><span class="k">Influencees</span><a href="https://www.influencees.com" rel="noopener">influencees.com</a></li>
          <li><span class="k">Autosave</span><a href="https://www.autosave.club" rel="noopener">autosave.club — Autosave Pte. Ltd., UEN 202431449C</a></li>
          <li><span class="k">Location</span><span>Singapore</span></li>
        </ul>
      </div>
    </section>
"""

# ===========================================================================
# PRESS — press kit at /press (bios, facts, downloadable photos)
# ===========================================================================

PRESS_PHOTOS = [
    {
        "slug": "davidson-chua-headshot",
        "display": "/assets/profile-800.webp",
        "download": "/assets/press/davidson-chua-headshot.jpg",
        "w": 800, "h": 800,
        "caption": "Davidson Chua — official headshot",
        "credit": "Davidson Chua (own work, CC BY-SA 4.0)",
        "date": "2026-08",
    },
    {
        "slug": "davidson-chua-nus-enterprise-portrait",
        "display": "/assets/press/davidson-chua-nus-enterprise-portrait.webp",
        "download": "/assets/press/davidson-chua-nus-enterprise-portrait.jpg",
        "w": 1200, "h": 675,
        "caption": "Davidson Chua at NUS Enterprise (BLOCK71), Singapore, June 2026",
        "credit": "Influencees · AMShots",
        "date": "2026-06",
    },
    {
        "slug": "influencees-cofounders-davidson-chua-edwin-koh",
        "display": "/assets/press/influencees-cofounders-davidson-chua-edwin-koh.webp",
        "download": "/assets/press/influencees-cofounders-davidson-chua-edwin-koh.jpg",
        "w": 1200, "h": 675,
        "caption": ("Influencees co-founders Edwin Koh (left) and Davidson Chua at NUS "
                    "Enterprise, Singapore, June 2026"),
        "credit": "Influencees · AMShots",
        "date": "2026-06",
    },
    {
        "slug": "davidson-chua-edwin-koh-block71",
        "display": "/assets/press/davidson-chua-edwin-koh-block71.webp",
        "download": "/assets/press/davidson-chua-edwin-koh-block71.jpg",
        "w": 1200, "h": 675,
        "caption": ("Influencees co-founders Davidson Chua (left) and Edwin Koh at "
                    "BLOCK71 Singapore, June 2026"),
        "credit": "Influencees · AMShots",
        "date": "2026-06",
    },
    {
        "slug": "davidson-chua-chargedup-2026-speaking",
        "display": "/assets/press/davidson-chua-chargedup-2026-speaking.webp",
        "download": "/assets/press/davidson-chua-chargedup-2026-speaking.jpg",
        "w": 800, "h": 1200,
        "caption": ("Davidson Chua (Founder, Autosave) speaking on the panel “Standards, "
                    "Experience & Adoption: Building an Interoperable EV Journey Across "
                    "Southeast Asia” at ChargedUp @ Singapore, July 2026"),
        "credit": "ChargedUp @ Singapore · @visualsbyadverse",
        "date": "2026-07-23",
    },
    {
        "slug": "davidson-chua-chargedup-2026-panel-stage",
        "display": "/assets/press/davidson-chua-chargedup-2026-panel-stage.webp",
        "download": "/assets/press/davidson-chua-chargedup-2026-panel-stage.jpg",
        "w": 1200, "h": 800,
        "caption": ("Panellists of the ChargedUp @ Singapore 2026 EV interoperability panel; "
                    "Davidson Chua (Founder, Autosave) second from right"),
        "credit": "ChargedUp @ Singapore · @visualsbyadverse",
        "date": "2026-07-23",
    },
    {
        "slug": "davidson-chua-chargedup-2026-panel-seated",
        "display": "/assets/press/davidson-chua-chargedup-2026-panel-seated.webp",
        "download": "/assets/press/davidson-chua-chargedup-2026-panel-seated.jpg",
        "w": 1200, "h": 800,
        "caption": ("Davidson Chua on stage during the ChargedUp @ Singapore 2026 panel "
                    "discussion"),
        "credit": "ChargedUp @ Singapore · @visualsbyadverse",
        "date": "2026-07-23",
    },
]


def press_body():
    figs = []
    for p in PRESS_PHOTOS:
        figs.append(f"""
          <figure class="pressPhoto">
            <img src="{p['display']}" width="{p['w']}" height="{p['h']}" loading="lazy"
                 alt="{html.escape(p['caption'])}">
            <figcaption>
              <span>{html.escape(p['caption'])}</span>
              <span class="muted small">Photo: {html.escape(p['credit'])}</span>
              <a class="small" href="{p['download']}" download>Download high-resolution JPG</a>
            </figcaption>
          </figure>""")
    photos_html = "\n".join(figs)

    return f"""
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">Press kit</p>
        <h1>Davidson Chua — Press Kit</h1>
        <p class="lead">Bios, facts and photography for journalists and event organisers.
          Everything on this page may be republished with the credits shown.
          For interviews and comment: <a href="mailto:davidsonchua@outlook.com">davidsonchua@outlook.com</a>.</p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Boilerplate bios</h2>
        <h3>One-liner</h3>
        <p class="muted">Davidson Chua is the co-founder and CEO of Influencees and the founder of
          Autosave, based in Singapore.</p>
        <h3>Short bio</h3>
        <p class="muted">Davidson Chua is the co-founder and CEO of Influencees, an AI-powered creator
          credibility and discovery platform for Southeast Asia, and the founder of Autosave,
          Singapore's most active automotive community with over 18,000 members. He holds a BSc
          (Honours) in Business Analytics from the National University of Singapore.</p>
        <h3>Name &amp; pronunciation</h3>
        <p class="muted">Davidson Chua (family name: Chua). Referred to as “Chua” on second
          reference.</p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Facts at a glance</h2>
        <ul class="contactList">
          <li><span class="k">Role</span><span>Co-founder &amp; CEO, Influencees; Founder, Autosave</span></li>
          <li><span class="k">Based in</span><span>Singapore</span></li>
          <li><span class="k">Influencees</span><span>AI-powered creator credibility &amp; discovery platform for
            Southeast Asia; launched June 2026; incubated via the NUS Venture Initiation Programme;
            undisclosed round from a corporate venture investor (April 2026)</span></li>
          <li><span class="k">Autosave</span><span>Singapore's most active automotive community; founded 2022;
            18,000+ members; Best Automotive Community &amp; Media Platform 2025 (Corporate Vision)</span></li>
          <li><span class="k">Education</span><span>BSc (Honours) in Business Analytics, National University of
            Singapore</span></li>
          <li><span class="k">Coverage</span><a href="/media">Selected media &amp; interviews →</a></li>
        </ul>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Photos</h2>
        <p class="muted">Click any photo to download the high-resolution version. Please keep the
          credit lines when republishing.</p>
        <div class="pressGrid">
{photos_html}
        </div>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Contact</h2>
        <ul class="contactList">
          <li><span class="k">Email</span><a href="mailto:davidsonchua@outlook.com">davidsonchua@outlook.com</a></li>
          <li><span class="k">Contact card</span><a href="/davidson-chua.vcf" download="Davidson Chua.vcf">Save contact (.vcf)</a></li>
          <li><span class="k">LinkedIn</span><a href="https://www.linkedin.com/in/davidsonchua/" rel="me noopener">linkedin.com/in/davidsonchua</a></li>
        </ul>
      </div>
    </section>
"""


def press_graph():
    imgs = []
    for p in PRESS_PHOTOS:
        imgs.append({
            "@type": "ImageObject",
            "@id": f"{BASE}/press#{p['slug']}",
            "contentUrl": f"{BASE}{p['download']}",
            "thumbnailUrl": f"{BASE}{p['display']}",
            "caption": p["caption"],
            "creditText": p["credit"],
            "about": {"@id": PERSON_ID},
            "representativeOfPage": p is PRESS_PHOTOS[0],
            "datePublished": p["date"],
            "inLanguage": "en-SG",
        })
    return [{
        "@type": "WebPage",
        "@id": f"{BASE}/press#webpage",
        "url": f"{BASE}/press",
        "name": "Davidson Chua — Press Kit",
        "isPartOf": {"@id": SITE_ID},
        "about": {"@id": PERSON_ID},
        "inLanguage": "en-SG",
        "dateModified": TODAY,
    }] + imgs


# ===========================================================================
# CARD — digital business card at /card + downloadable vCard
# ===========================================================================

def make_vcf():
    """Write site/davidson-chua.vcf (vCard 3.0, headshot embedded as base64 JPEG)."""
    import base64, io
    photo_b64 = ""
    try:
        from PIL import Image
        src = os.path.join(OUT, "assets", "profile-800.webp")
        im = Image.open(src).convert("RGB").resize((480, 480))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=82, optimize=True)
        photo_b64 = base64.b64encode(buf.getvalue()).decode()
    except Exception as e:
        print("vcf: photo skipped:", e)

    lines = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        "N:Chua;Davidson;;;",
        "FN:Davidson Chua",
        "ORG:Influencees",
        "TITLE:Co-founder & CEO",
        "EMAIL;TYPE=INTERNET,WORK:davidson.chua@influencees.com",
        "EMAIL;TYPE=INTERNET:davidsonchua@outlook.com",
        "URL:https://davidsonchua.cc",
        "item1.URL:https://www.linkedin.com/in/davidsonchua/",
        "item1.X-ABLabel:LinkedIn",
        "item2.URL:https://www.instagram.com/davidsonchua",
        "item2.X-ABLabel:Instagram",
        "item3.URL:https://x.com/davidsonchua",
        "item3.X-ABLabel:X",
        "item4.URL:https://t.me/davidsonchua",
        "item4.X-ABLabel:Telegram",
        "ADR;TYPE=WORK:;;;;;;Singapore",
        "NOTE:Co-founder & CEO of Influencees; founder of Autosave (18,000+ member "
        "automotive community). davidsonchua.cc",
        f"REV:{TODAY}T00:00:00Z",
    ]
    if photo_b64:
        lines.append("PHOTO;ENCODING=b;TYPE=JPEG:" + photo_b64)
    lines.append("END:VCARD")

    # RFC line folding: max 75 octets/line, continuations start with a space.
    folded = []
    for ln in lines:
        folded.append(ln[:74])
        ln = ln[74:]
        while ln:
            folded.append(" " + ln[:73])
            ln = ln[73:]
    with open(os.path.join(OUT, "davidson-chua.vcf"), "wb") as f:
        f.write("\r\n".join(folded).encode("utf-8") + b"\r\n")
    print("wrote site/davidson-chua.vcf")


CARD_BODY = """
    <section class="cardPage">
      <div class="vcard">
        <img class="vcardPhoto" src="/assets/profile-400.webp" width="120" height="120"
             alt="Portrait of Davidson Chua">
        <h1>Davidson Chua</h1>
        <p class="vcardTitle">Co-founder &amp; CEO, Influencees<br>Founder, Autosave</p>

        <a class="btn vcardSave" href="/davidson-chua.vcf" download="Davidson Chua.vcf">Save my contact</a>

        <div class="vcardLinks">
          <a class="btn ghost" href="mailto:davidson.chua@influencees.com">Email</a>
          <a class="btn ghost" href="https://www.linkedin.com/in/davidsonchua/" rel="me noopener">LinkedIn</a>
          <a class="btn ghost" href="https://www.instagram.com/davidsonchua" rel="me noopener">Instagram</a>
          <a class="btn ghost" href="https://t.me/davidsonchua" rel="me noopener">Telegram</a>
        </div>

        <figure class="vcardQr">
          <img src="/assets/card-qr.png" width="132" height="132" loading="lazy"
               alt="QR code that opens davidsonchua.cc/card">
          <figcaption>Scan to open this card</figcaption>
        </figure>

        <p class="vcardHome"><a href="/">davidsonchua.cc</a></p>
      </div>
    </section>
"""


def card_html():
    """Standalone card page: no site nav/footer, same schema graph."""
    graph = list(CORE_GRAPH) + [{
        "@type": "WebPage",
        "@id": f"{BASE}/card#webpage",
        "url": f"{BASE}/card",
        "name": "Davidson Chua — digital business card",
        "isPartOf": {"@id": SITE_ID},
        "about": {"@id": PERSON_ID},
        "inLanguage": "en-SG",
        "dateModified": TODAY,
    }]
    jsonld = json.dumps({"@context": "https://schema.org", "@graph": graph},
                        indent=2, ensure_ascii=False)
    h = head(
        title="Davidson Chua — Digital Business Card",
        desc=("Save Davidson Chua's contact details in one tap — co-founder & CEO of "
              "Influencees, founder of Autosave, Singapore."),
        path="/card",
    )
    return f"""<!doctype html>
<html lang="en-SG">
<head>
  {h}

  <script type="application/ld+json">
{jsonld}
  </script>
</head>
<body>
  <main id="main">
{CARD_BODY}
  </main>
</body>
</html>
"""


# ===========================================================================
# WRITING
# ===========================================================================

POSTS = [
    {
        "slug": "follower-count-is-a-bad-proxy-for-trust",
        "title": "Follower count is a bad proxy for trust",
        "desc": ("Why the creator economy's default metric measures the wrong thing, and what "
                 "building a 18,000-member community taught Davidson Chua about credibility."),
        "date": "2026-08-16",
        "readable_date": "16 August 2026",
        "body": """
        <p>I have spent the last four years on both sides of a lot of brand deals. First as the
        person running <a href="https://www.autosave.club" rel="noopener">Autosave</a>, a car
        community in Singapore that grew from a Telegram group into something with 18,000-odd
        members. Then as the person building
        <a href="https://www.influencees.com" rel="noopener">Influencees</a>, which exists because of
        a problem I kept running into from the first side.</p>

        <p>The problem is this. When a brand decides who to work with, the number they reach for
        first is follower count. It is the only number that is visible, standardised and free. And
        it is close to useless.</p>

        <h2>What follower count actually measures</h2>
        <p>Follower count measures accumulated reach. It tells you how many accounts, at some point,
        pressed a button. It does not tell you whether those accounts are still active, whether they
        see the content, whether they believe it, or whether they would act on a recommendation.</p>

        <p>In a car community you notice this fast, because the feedback loop is short and physical.
        Someone posts a recommendation about a workshop, a tint shop, a tyre. If they are trusted,
        people go. If they are not, nothing happens, and everyone can see that nothing happened.
        After a while you learn who moves people and who just has an audience.</p>

        <p>The two lists barely overlap.</p>

        <h2>The most valuable creators are often not the biggest</h2>
        <p>Some of the most valuable people I worked with at Autosave had a few thousand followers.
        They had spent years answering questions in comments, they owned the car they were talking
        about, and when they said something was worth buying, members bought it. Meanwhile plenty of
        larger accounts produced campaign posts that sank without trace.</p>

        <p>This is not a novel observation — everyone in the industry says it. What nobody had was a
        way to act on it. If you cannot measure credibility, you fall back on the number you can
        measure, even knowing it is the wrong one. That is not stupidity, it is the absence of an
        alternative.</p>

        <h2>Why self-reported data does not fix it</h2>
        <p>The usual patch is a media kit: a creator sends over engagement rates, audience
        demographics, past campaign results. The problem is obvious once you have seen a few. The
        creator picks which numbers to show, which window to show them over, and which campaigns to
        mention. It is a CV, not an audit.</p>

        <p>I do not think creators are being dishonest when they do this. Everybody presents their
        best case. But a market where every participant self-reports their own quality is a market
        with no price signal.</p>

        <h2>What we built instead</h2>
        <p>Influencees syncs performance data directly from Instagram and TikTok rather than
        accepting what a creator reports. That single change does most of the work: the same
        methodology applied to every creator, over the same window, without anyone choosing which
        slice to show.</p>

        <p>On top of that sits the part I actually care about — credibility signals. Consistency over
        time. Whether engagement comes from an audience that behaves like a real audience. Whether
        the creator's stated niche matches what they actually post. None of this is exotic
        analytics. It is just what you would check manually if you had the time, applied to 1,200+
        creators instead of five.</p>

        <p>The goal is not to replace judgement. It is to make sure the judgement starts from a
        number that means something.</p>

        <h2>The uncomfortable part</h2>
        <p>A trust layer only works if it is willing to say unflattering things. A credibility score
        that never comes back low is a marketing asset, not a measurement. That tension is the whole
        business, and it is the part we will get judged on.</p>

        <p>Communities taught me that trust is not a feature you ship. It is the accumulated
        residue of being right in public, repeatedly, including when it costs you something. I would
        like the infrastructure to reflect that.</p>
        """,
    }
]

EXTERNAL_WRITING = [
    ("Why are cars in Singapore getting bigger in 2025?",
     "https://medium.com/motoringclub/why-are-cars-in-singapore-getting-bigger-in-2025-1df9a1b4cb09",
     "MotoringClub"),
    ("ERP 2 location-based charging is coming",
     "https://baycityculture.com/", "Bay City Culture"),
    ("Nearly 6 in 10 new cars registered in Singapore are now EVs",
     "https://baycityculture.com/", "Bay City Culture"),
    ("When can an EV battery be repaired, and when must it be replaced?",
     "https://baycityculture.com/", "Bay City Culture"),
    ("The problem with bicycles in Singapore",
     "https://davidsonchua.medium.com/the-problem-with-bicycles-in-singapore-aec9947b6b03",
     "Medium"),
]


def writing_index_body():
    native = "\n".join(
        f"""          <li>
            <h3><a href="/writing/{p['slug']}">{html.escape(p['title'])}</a></h3>
            <div class="postMeta">{p['readable_date']}</div>
            <p>{html.escape(p['desc'])}</p>
          </li>""" for p in POSTS)
    external = "\n".join(
        f"""          <li>
            <h3><a href="{u}" rel="noopener">{html.escape(t)}</a></h3>
            <div class="postMeta">{html.escape(src)}</div>
          </li>""" for t, u, src in EXTERNAL_WRITING)
    return f"""
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">Writing</p>
        <h1>Writing by Davidson Chua</h1>
        <p class="lead">Notes on the creator economy, community building, and Singapore's
          automotive and EV market.</p>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Here</h2>
        <ul class="posts">
{native}
        </ul>
      </div>
    </section>

    <section class="section">
      <div class="shell">
        <h2>Elsewhere</h2>
        <p class="muted small">Published on
          <a href="https://baycityculture.com/" rel="noopener">Bay City Culture</a> and
          <a href="https://davidsonchua.medium.com/" rel="noopener">Medium</a>.</p>
        <ul class="posts">
{external}
        </ul>
      </div>
    </section>
"""


def post_body(p):
    return f"""
    <article class="article">
      <div class="shell">
        <p class="eyebrow">Writing</p>
        <h1>{html.escape(p['title'])}</h1>
        <div class="articleMeta">By Davidson Chua · <time datetime="{p['date']}">{p['readable_date']}</time></div>
        <div class="articleBody">
{p['body']}
        </div>

        <div class="authorBox">
          <img src="/assets/profile-264.webp" width="56" height="56" loading="lazy"
               alt="Davidson Chua">
          <div>
            <strong>Davidson Chua</strong>
            <p>Co-founder &amp; CEO of <a href="https://www.influencees.com" rel="noopener">Influencees</a>
              and founder of <a href="https://www.autosave.club" rel="noopener">Autosave</a>, based in
              Singapore. <a href="/about">More about me →</a></p>
          </div>
        </div>
      </div>
    </article>
"""


# ===========================================================================
# 404
# ===========================================================================

NOTFOUND_BODY = """
    <section class="section tight">
      <div class="shell">
        <p class="eyebrow">404</p>
        <h1>Page not found</h1>
        <p class="lead">That page doesn't exist. Try the <a href="/">homepage</a> or read
          <a href="/about">about Davidson Chua</a>.</p>
      </div>
    </section>
"""


# ===========================================================================
# BUILD
# ===========================================================================

def build():
    # ---- Home
    write("/", page(
        path="/",
        title="Davidson Chua — Influencees Co-founder & CEO, Autosave Founder",
        desc=("Davidson Chua is a Singapore-based founder and community builder. Co-founder & CEO of "
              "Influencees, the creator credibility platform for Southeast Asia, and founder of "
              "Autosave, Singapore's most active automotive community (18,000+ members)."),
        body=HOME_BODY,
        current="/",
        graph_extra=[{
            "@type": "WebPage",
            "@id": f"{BASE}/#webpage",
            "url": f"{BASE}/",
            "name": "Davidson Chua — Co-founder & CEO of Influencees, Founder of Autosave",
            "isPartOf": {"@id": SITE_ID},
            "about": {"@id": PERSON_ID},
            "primaryImageOfPage": {"@id": f"{BASE}/#primaryimage"},
            "inLanguage": "en-SG",
            "datePublished": "2026-01-01",
            "dateModified": TODAY,
        }],
    ))

    # ---- About (Entity Home: ProfilePage)
    write("/about", page(
        path="/about",
        title="About Davidson Chua — Co-founder & CEO of Influencees",
        desc=("Full biography of Davidson Chua: Singapore-based co-founder and CEO of Influencees, "
              "founder of Autosave, NUS Business Analytics graduate. Career, ventures, education "
              "and verified profiles."),
        body=ABOUT_BODY,
        current="/about",
        og_type="profile",
        graph_extra=[{
            "@type": "ProfilePage",
            "@id": f"{BASE}/about#profilepage",
            "url": f"{BASE}/about",
            "name": "About Davidson Chua",
            "isPartOf": {"@id": SITE_ID},
            "mainEntity": {"@id": PERSON_ID},
            "about": {"@id": PERSON_ID},
            "primaryImageOfPage": {"@id": f"{BASE}/#primaryimage"},
            "inLanguage": "en-SG",
            "dateCreated": "2026-01-01",
            "dateModified": TODAY,
            "breadcrumb": {"@id": f"{BASE}/about#breadcrumb"},
        }, {
            "@type": "BreadcrumbList",
            "@id": f"{BASE}/about#breadcrumb",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": f"{BASE}/"},
                {"@type": "ListItem", "position": 2, "name": "About", "item": f"{BASE}/about"},
            ],
        }],
    ))

    # ---- Ventures
    write("/ventures", page(
        path="/ventures",
        title="Ventures — Companies Founded by Davidson Chua",
        desc=("Influencees, the AI-powered creator credibility platform for Southeast Asia, and "
              "Autosave, Singapore's most active automotive community — both founded by Davidson Chua."),
        body=VENTURES_BODY,
        current="/ventures",
        graph_extra=[{
            "@type": "CollectionPage",
            "@id": f"{BASE}/ventures#webpage",
            "url": f"{BASE}/ventures",
            "name": "Ventures — Companies Founded by Davidson Chua",
            "isPartOf": {"@id": SITE_ID},
            "about": {"@id": PERSON_ID},
            "inLanguage": "en-SG",
            "dateModified": TODAY,
            "mainEntity": {
                "@type": "ItemList",
                "itemListElement": [
                    {"@type": "ListItem", "position": 1, "item": {"@id": INFLUENCEES_ID}},
                    {"@type": "ListItem", "position": 2, "item": {"@id": AUTOSAVE_ID}},
                ],
            },
            "breadcrumb": {"@id": f"{BASE}/ventures#breadcrumb"},
        }, {
            "@type": "BreadcrumbList",
            "@id": f"{BASE}/ventures#breadcrumb",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": f"{BASE}/"},
                {"@type": "ListItem", "position": 2, "name": "Ventures", "item": f"{BASE}/ventures"},
            ],
        }],
    ))

    # ---- Media
    write("/media", page(
        path="/media",
        title="Media & Press — Davidson Chua",
        desc=("Press features, podcast appearances and speaking engagements for Davidson Chua, "
              "including The Straits Times, ST Work Talk, NUS Computing and ChargedUp 2026."),
        body=MEDIA_BODY,
        current="/media",
        graph_extra=[{
            "@type": "CollectionPage",
            "@id": f"{BASE}/media#webpage",
            "url": f"{BASE}/media",
            "name": "Media & Press — Davidson Chua",
            "isPartOf": {"@id": SITE_ID},
            "about": {"@id": PERSON_ID},
            "inLanguage": "en-SG",
            "dateModified": TODAY,
            "breadcrumb": {"@id": f"{BASE}/media#breadcrumb"},
        }, {
            "@type": "BreadcrumbList",
            "@id": f"{BASE}/media#breadcrumb",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": f"{BASE}/"},
                {"@type": "ListItem", "position": 2, "name": "Media", "item": f"{BASE}/media"},
            ],
        }],
    ))

    # ---- Contact
    write("/contact", page(
        path="/contact",
        title="Contact Davidson Chua — Singapore",
        desc=("Get in touch with Davidson Chua, founder of Influencees and Autosave. Email, "
              "LinkedIn, Telegram, press bio and headshot."),
        body=CONTACT_BODY,
        current="/contact",
        graph_extra=[{
            "@type": "ContactPage",
            "@id": f"{BASE}/contact#webpage",
            "url": f"{BASE}/contact",
            "name": "Contact Davidson Chua",
            "isPartOf": {"@id": SITE_ID},
            "about": {"@id": PERSON_ID},
            "mainEntity": {"@id": PERSON_ID},
            "inLanguage": "en-SG",
            "dateModified": TODAY,
            "breadcrumb": {"@id": f"{BASE}/contact#breadcrumb"},
        }, {
            "@type": "BreadcrumbList",
            "@id": f"{BASE}/contact#breadcrumb",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": f"{BASE}/"},
                {"@type": "ListItem", "position": 2, "name": "Contact", "item": f"{BASE}/contact"},
            ],
        }],
    ))

    # ---- Writing index
    write("/writing", page(
        path="/writing",
        title="Writing — Davidson Chua",
        desc=("Essays and notes by Davidson Chua on the creator economy, community building and "
              "Singapore's automotive and EV market."),
        body=writing_index_body(),
        current="/writing",
        graph_extra=[{
            "@type": "Blog",
            "@id": f"{BASE}/writing#blog",
            "url": f"{BASE}/writing",
            "name": "Writing — Davidson Chua",
            "description": "Essays on the creator economy, community building and Singapore motoring.",
            "isPartOf": {"@id": SITE_ID},
            "author": {"@id": PERSON_ID},
            "publisher": {"@id": PERSON_ID},
            "inLanguage": "en-SG",
            "blogPost": [{"@id": f"{BASE}/writing{p['slug']}/#article"} for p in POSTS],
            "breadcrumb": {"@id": f"{BASE}/writing#breadcrumb"},
        }, {
            "@type": "BreadcrumbList",
            "@id": f"{BASE}/writing#breadcrumb",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": f"{BASE}/"},
                {"@type": "ListItem", "position": 2, "name": "Writing", "item": f"{BASE}/writing"},
            ],
        }],
    ))

    # ---- Posts
    for p in POSTS:
        url = f"{BASE}/writing{p['slug']}/"
        write(f"/writing/{p['slug']}", page(
            path=f"/writing/{p['slug']}",
            title=f"{p['title']} — Davidson Chua",
            desc=p["desc"],
            body=post_body(p),
            current="/writing",
            og_type="article",
            graph_extra=[{
                "@type": "BlogPosting",
                "@id": f"{url}#article",
                "headline": p["title"],
                "description": p["desc"],
                "url": url,
                "mainEntityOfPage": {"@type": "WebPage", "@id": url},
                "datePublished": p["date"],
                "dateModified": p["date"],
                "author": {"@id": PERSON_ID},
                "publisher": {"@id": PERSON_ID},
                "isPartOf": {"@id": f"{BASE}/writing#blog"},
                "image": {"@id": f"{BASE}/#primaryimage"},
                "inLanguage": "en-SG",
                "about": [
                    {"@type": "Thing", "name": "Creator economy"},
                    {"@type": "Thing", "name": "Influencer marketing"},
                    {"@id": INFLUENCEES_ID},
                ],
                "breadcrumb": {
                    "@type": "BreadcrumbList",
                    "itemListElement": [
                        {"@type": "ListItem", "position": 1, "name": "Home", "item": f"{BASE}/"},
                        {"@type": "ListItem", "position": 2, "name": "Writing", "item": f"{BASE}/writing"},
                        {"@type": "ListItem", "position": 3, "name": p["title"], "item": url},
                    ],
                },
            }],
        ))

    # ---- Press kit
    write("/press", page(
        path="/press",
        title="Press Kit — Davidson Chua",
        desc=("Press kit for Davidson Chua: boilerplate bios, facts, and downloadable "
              "high-resolution photos for journalists and event organisers."),
        body=press_body(),
        graph_extra=press_graph(),
    ))

    # ---- Card (+ vCard file)
    write("/card", card_html())
    make_vcf()

    # ---- 404 (flat file)
    nf = page(path="/404.html", title="Page not found — Davidson Chua",
              desc="Page not found on davidsonchua.cc", body=NOTFOUND_BODY)
    nf = nf.replace('<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">',
                    '<meta name="robots" content="noindex, follow">')
    with open(os.path.join(OUT, "404.html"), "w", encoding="utf-8") as f:
        f.write(nf)
    print("wrote site/404.html")

    # ---- sitemap.xml
    urls = [("/", "1.0"), ("/about", "0.9"), ("/ventures", "0.8"),
            ("/writing", "0.8"), ("/media", "0.7"), ("/contact", "0.6"),
            ("/card", "0.4"), ("/press", "0.5")]
    urls += [(f"/writing/{p['slug']}", "0.7") for p in POSTS]
    entries = "\n".join(
        f"  <url>\n    <loc>{BASE}{u}</loc>\n    <lastmod>{TODAY}</lastmod>\n  </url>"
        for u, _ in urls)
    with open(os.path.join(OUT, "sitemap.xml"), "w", encoding="utf-8") as f:
        f.write(f'<?xml version="1.0" encoding="UTF-8"?>\n'
                f'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{entries}\n</urlset>\n')
    print("wrote site/sitemap.xml")

    # ---- robots.txt
    with open(os.path.join(OUT, "robots.txt"), "w", encoding="utf-8") as f:
        f.write(f"""# davidsonchua.cc
User-agent: *
Allow: /

# AI crawlers are welcome — being cited in AI answers is a discovery channel.
User-agent: GPTBot
Allow: /

User-agent: OAI-SearchBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: Google-Extended
Allow: /

Sitemap: {BASE}/sitemap.xml
""")
    print("wrote site/robots.txt")

    # ---- llms.txt
    with open(os.path.join(OUT, "llms.txt"), "w", encoding="utf-8") as f:
        f.write(f"""# Davidson Chua

> Davidson Chua is a Singapore-based founder and community builder. He is the founder and
> co-founder and CEO of Influencees, an AI-powered creator credibility and discovery platform for Southeast
> Asia, and the founder of Autosave, Singapore's most active automotive community with more
> than 18,000 members. He holds a BSc (Honours) in Business Analytics from the National
> University of Singapore. Autosave was named Best Automotive Community & Media Platform
> 2025 (Singapore) in Corporate Vision's Automotive Awards.

## Pages

- [About Davidson Chua]({BASE}/about): Full biography, career history, education and verified profiles.
- [Ventures]({BASE}/ventures): Influencees and Autosave in detail.
- [Writing]({BASE}/writing): Essays on the creator economy and Singapore motoring.
- [Media]({BASE}/media): Press features, podcasts and speaking.
- [Contact]({BASE}/contact): Email, social profiles, press bio and headshot.

## Selected coverage

- Tech in Asia Startup Spotlight, 31 August 2026: "Meet the AI platform that helps brands evaluate content creators" — https://www.techinasia.com/meet-ai-platform-helps-brands-evaluate-content-creators
- TNGlobal Q&A, 24 August 2026: "Influencees' Davidson Chua on measuring creator influence beyond follower count" — https://technode.global/2026/08/24/influencees-davidson-chua-on-measuring-creator-influence-beyond-follower-count-qa/
- NUS Computing profile: https://www.comp.nus.edu.sg/news/how-influencees-is-building-the-ai-layer-for-the-creator-economy/
- BLOCK71 Global feature on Autosave, 23 June 2026: https://block71.co/heres-what-founders-are-talking-about-on-social-this-month/

## Verified profiles

- LinkedIn: https://www.linkedin.com/in/davidsonchua/
- Crunchbase: https://www.crunchbase.com/person/davidson-chua-cc
- Medium: https://davidsonchua.medium.com/
- X: https://x.com/davidsonchua
- Telegram: https://t.me/davidsonchua

## Disambiguation

Other people share the name "Davidson Chua". This site refers specifically to the founder of
Influencees and Autosave, based in Singapore.
""")
    print("wrote site/llms.txt")

    # ---- RSS
    items = "\n".join(f"""    <item>
      <title>{html.escape(p['title'])}</title>
      <link>{BASE}/writing{p['slug']}/</link>
      <guid isPermaLink="true">{BASE}/writing{p['slug']}/</guid>
      <description>{html.escape(p['desc'])}</description>
      <dc:creator>Davidson Chua</dc:creator>
    </item>""" for p in POSTS)
    os.makedirs(os.path.join(OUT, "writing"), exist_ok=True)
    with open(os.path.join(OUT, "writing", "feed.xml"), "w", encoding="utf-8") as f:
        f.write(f"""<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>Davidson Chua — Writing</title>
    <link>{BASE}/writing</link>
    <atom:link href="{BASE}/writingfeed.xml" rel="self" type="application/rss+xml"/>
    <description>Essays on the creator economy, community building and Singapore motoring.</description>
    <language>en-SG</language>
{items}
  </channel>
</rss>
""")
    print("wrote site/writing/feed.xml")

    # ---- webmanifest
    with open(os.path.join(OUT, "site.webmanifest"), "w", encoding="utf-8") as f:
        json.dump({
            "name": "Davidson Chua",
            "short_name": "Davidson Chua",
            "start_url": "/",
            "display": "standalone",
            "background_color": "#ffffff",
            "theme_color": "#ffffff",
            "icons": [
                {"src": "/web-app-manifest-192x192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable"},
                {"src": "/web-app-manifest-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
            ],
        }, f, indent=2)
    print("wrote site/site.webmanifest")

    # ---- vercel.json (matches the existing deployment: cleanUrls, no trailing slash)
    with open(os.path.join(OUT, "vercel.json"), "w", encoding="utf-8") as f:
        json.dump({
            "cleanUrls": True,
            "trailingSlash": False,
            "redirects": [
                {"source": "/index.html", "destination": "/", "permanent": True},
                {"source": "/about.html", "destination": "/about", "permanent": True},
            ],
            "headers": [
                {"source": "/(.*)", "headers": [
                    {"key": "X-Content-Type-Options", "value": "nosniff"},
                    {"key": "Referrer-Policy", "value": "strict-origin-when-cross-origin"},
                    {"key": "Strict-Transport-Security", "value": "max-age=63072000; includeSubDomains; preload"},
                    {"key": "X-Frame-Options", "value": "SAMEORIGIN"},
                    {"key": "Permissions-Policy", "value": "geolocation=(), microphone=(), camera=()"},
                ]},
                {"source": "/assets/(.*)", "headers": [
                    {"key": "Cache-Control", "value": "public, max-age=31536000, immutable"},
                ]},
                {"source": "/davidson-chua.vcf", "headers": [
                    {"key": "Content-Type", "value": "text/vcard; charset=utf-8"},
                    {"key": "Content-Disposition",
                     "value": "attachment; filename=\"Davidson Chua.vcf\""},
                ]},
            ],
        }, f, indent=2)
    print("wrote site/vercel.json")


if __name__ == "__main__":
    build()
